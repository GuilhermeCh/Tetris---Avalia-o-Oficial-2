public @interface Test {

}
